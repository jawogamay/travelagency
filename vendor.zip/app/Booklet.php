<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class Booklet extends Model
{
    use Notifiable, HasApiTokens;

    public function user(){
        return $this->belongsTo('App\User');
    }
}
